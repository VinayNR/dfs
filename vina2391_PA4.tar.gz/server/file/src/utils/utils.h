#pragma once

#include <string>
#include <unordered_map>

void deleteAndNullifyPointer(char *&, bool);

unsigned int computeMD5(const std::string &);
