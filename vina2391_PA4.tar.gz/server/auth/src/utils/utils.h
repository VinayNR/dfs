#pragma once

#include <string>
#include <unordered_map>

void deleteAndNullifyPointer(char *&, bool);
