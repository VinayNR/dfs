#pragma once

#include <string>

struct ResourceLocation {
    std::string ip;
    int port;
};