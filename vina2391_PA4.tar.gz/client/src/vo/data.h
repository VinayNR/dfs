#pragma once

#include <cstddef>

struct Data {
    char *data;
    size_t size;
};