#pragma once

#include <string>

struct Command {
    std::string type;
    std::string option;
};