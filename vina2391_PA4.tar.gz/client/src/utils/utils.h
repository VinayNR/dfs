#pragma once

void deleteAndNullifyPointer(char *&, bool);
